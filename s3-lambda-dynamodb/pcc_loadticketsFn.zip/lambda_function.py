import json
import boto3
import os
import csv
import codecs
import sys

s3 = boto3.resource('s3')
dynamodb = boto3.resource('dynamodb')
tableName = os.environ['tickets_dynamodb_table']

def lambda_handler(event, context):
   #get() does not store in memory
   try:
      bucket = event['Records'][0]['s3']['bucket']['name']
      key = event['Records'][0]['s3']['object']['key']
      obj = s3.Object(bucket, key).get()['Body']
      print('Reading {} from {}'.format(key, bucket))
   except Exception as error:
      print(error)
      print("S3 Object could not be opened.")
   try:
      table = dynamodb.Table(tableName)
   except Exception as error:
      print(error)
      print("Error loading DynamoDB table. Check if table was created correctly")

   batch_size = 200
   batch = []

   #DictReader is a generator; not stored in memory
   for row in csv.DictReader(codecs.getreader('utf-8-sig')(obj)):
      if len(batch) >= batch_size:
         write_to_dynamo(batch)
         batch.clear()
      batch.append(row)

   if batch:
      write_to_dynamo(batch)

   return {
      'statusCode': 200,
      'body': json.dumps('Uploaded to DynamoDB Table')
   }


def write_to_dynamo(rows):
   try:
      table = dynamodb.Table(tableName)
   except Exception as error:
      print(error)
      print("Error loading DynamoDB table. Check if table was created correctly")

   try:
      with table.batch_writer(overwrite_by_pkeys=["Barcode","Order_ID"]) as batch:
         for i in range(len(rows)):
            batch.put_item(
               Item=rows[i]
            )
   except Exception as error:
      print(error)
      print("Error executing batch_writer")